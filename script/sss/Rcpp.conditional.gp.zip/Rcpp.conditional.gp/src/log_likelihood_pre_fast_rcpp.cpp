// log_likelihood_pre_fast.cpp
// Compile with: Rcpp::sourceCpp("log_likelihood_pre_fast.cpp")

#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;

// -----------------------------------------------------------------
// log_likelihood_pre_fast_rcpp
// new_data, old_data: vectors
// C_full: precomputed covariance matrix from R
// Returns conditional log-likelihood
// -----------------------------------------------------------------

// [[Rcpp::export]]
double log_likelihood_pre_fast_rcpp(const arma::vec& new_data,
                                    const arma::vec& old_data,
                                    const arma::mat& C_full) {
  
  int N1 = new_data.n_elem;
  int N2 = old_data.n_elem;
  int N  = N1 + N2;
  
  // slice old covariance
  arma::mat C_old = C_full.submat(N1, N1, N-1, N-1);
  
  // joint log-density
  arma::vec y_full = arma::join_cols(new_data, old_data);
  
  arma::mat L_full = arma::chol(C_full, "lower");
  arma::vec alpha_full = arma::solve(arma::trimatl(L_full), y_full);
  alpha_full = arma::solve(arma::trimatu(L_full.t()), alpha_full);
  
  double logdet_full = 2.0 * sum(log(L_full.diag()));
  double loglik_full = -0.5 * (dot(y_full, alpha_full) + logdet_full + N * std::log(2.0 * M_PI));
  
  // old log-density
  arma::mat L_old = arma::chol(C_old, "lower");
  arma::vec alpha_old = arma::solve(arma::trimatl(L_old), old_data);
  alpha_old = arma::solve(arma::trimatu(L_old.t()), alpha_old);
  
  double logdet_old = 2.0 * sum(log(L_old.diag()));
  double loglik_old = -0.5 * (dot(old_data, alpha_old) + logdet_old + N2 * std::log(2.0 * M_PI));
  
  return loglik_full - loglik_old;
}
